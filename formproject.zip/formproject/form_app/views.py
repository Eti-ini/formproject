from django.shortcuts import render

# Create your views here.
from form_app import forms

def index(request):
    return render(request, 'form_app/index.html')

def form_name_view(request):
    form = forms.FormName()
    return render(request, 'form_app/index2.html', {'form': form})

def form_name_view(request):
    form = forms.FormName
    if request.method == 'POST':
        form = forms.FormName(request.POST)

        if form.is_valid():
            print('Vaidation success')
            print("Name " + form.cleaned_data['name'])
            print("Email " + form.cleaned_data['email'])
            print("Text " + form.cleaned_data['text'])
    return render(request, 'form_app/index2.html', {'form': form})
